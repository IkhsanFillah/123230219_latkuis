<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kuis</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="latkuis.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bgnav">
        <div class="d-flex fs-6 font-weight-bold">    
            <div class="mt-2 ms-5 hnav">Kuis 123230219</div>
            <ul class="d-flex list-unstyled">
                <li class="ms-5 p-2 mt-1"><a href="home.php" class="text-decoration-none text-dark anav">home</a></li>
                <li class="p-2 mt-1"><a href="form.php" class="text-decoration-none text-dark anav">form</a></li>
                <li class="p-2 mt-1"><a href="perulangan.php" class="text-decoration-none text-dark anav">perulangan</a></li>
            </ul>
        </div>
    </nav>
    <section class="p-7">
        <h1 class="text-center mt-2">Ujung Kareung</h1>
        <div class="pt-1 ps-5 mt-1 d-flex ">
            <img src="Ujung_Kareung.jpg" class="img-30">
            <p class="p1 ms-2">Pantai Ujong Kareung yang terletak di Desa Suak Indrapuri Kecamatan Johan Pahlawan, Meulaboh, Aceh Barat Provinsi Aceh ini menjadi salah satu wisata yang banyak diminati oleh para pengunjung, baik pengunjung lokal maupun luar daerah. Para pengunjung umumnya akan memadati lokasi ini pada weekend maupun hari libur nasional. pantai ini juga berjarak kurang lebih sekitar 1,5 kilometer dari pusat Kota Meulaboh dan  membutuhkan waktu sekitar 10 menit untuk mencapai lokasi wisata ini. Pantai ini memang cocok dijadikan tujuan wisata karena keindahan alam yang ditampilkan dapat menghilangkan rasa lelah serta penat akibat rutinitas bekerja sehari-hari.
            <br><br> Ujong Kareung sendiri diambil dari Bahasa Aceh yang berarti Ujung Karang. Nama ini sesuai dengan dengan lokasi pantai yang berada di ujung kota Meulaboh dan dipenuhi dengan batu-batu karang. Tepat pada tanggal 26 Desember 2004, pantai ini menjadi saksi bisu dari dahsyatnya Gelombang Tsunami yang menerjang Aceh. Saat ini para pengunjung dapat menyaksikan sisa-sisa dari bangunan peninggalan tsunami seperti Gedung Makoren 012/Teuku Umar serta mercusuar. Menurut cerita warga sekitar, korban dari bencana tsunami ini juga dimakamkan secara massal di Kuburan Massal yang berlokasi di sekitar pantai.</p>
        </div>
        <div class="pt-1 ps-5 mt-1">
            <h1 class="mt-2">Fasilitas di Pantai Ujung Kareung</h1>
            <p class="p1">Di lokasi ini para pengunjung tidak hanya dapat menikmati keindahan alam saja. Namun, di pantai ini juga para pengunjung dapat melakukan kegiatan lain, salah satunya seperti memancing. Yap, di lokasi ini memang para pengunjung dapat menyalurkan hobi memancing. jangan khawatir, di sini juga terdapat tempat penyewaan alat pancing. Bagi para pengunjung yang hobi memancing tak ada salahnya untuk mencoba memancing di area pantai ini sambil menikmati keindahan pantai yang sangat cantik.
            <br><br>Selain itu bagi para pengunjung yang lupa tidak membawa bekal makanan, jangan khawatir. Karena di lokasi ini juga telah tersedia berbagai tempat makan ataupun cafe-cafe yang menawarkan berbagai jenis makanan serta minuman yang cukup menggugah selera. Menu makanan yang disediakan seperti mie kuah dengan bumbu khas Aceh, berbagai jenis makanan seafood, rujak buah, dan masih banyak lagi. Anda juga bisa menikmati sendiri hasil tangkapan ikan dari memancing dengan membakar ikan tersebut di tepi pantai. Suasana indah nan seru seperti ini pasti tidak akan pernah terlupakan.</p>
        </div>
    </section>
    <footer class="footer2">
        <h3 class="">&copy; Praktikum Pemrogram Web IF 2022</h3>
    </footer>
</body>
</html>