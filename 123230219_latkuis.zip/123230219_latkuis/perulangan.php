<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kuis</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="latkuis.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bgnav">
        <div class="d-flex fs-6 font-weight-bold">    
            <div class="mt-2 ms-5 hnav">Kuis 123230219</div>
            <ul class="d-flex list-unstyled">
                <li class="ms-5 p-2 mt-1"><a href="home.php" class="text-decoration-none text-dark anav">home</a></li>
                <li class="p-2 mt-1"><a href="form.php" class="text-decoration-none text-dark anav">form</a></li>
                <li class="p-2 mt-1"><a href="perulangan.php" class="text-decoration-none text-dark anav">perulangan</a></li>
            </ul>
        </div>
    </nav>
    <div class="container">
        <h2 class="text-center mb-4 mt-3">Reverse Words</h2>
        <form method="post" action="" >
            <div class="mb-3">
                <label for="input_text" class="form-label">Input Kata/Kalimat:</label>
                <input type="text" class="form-control" id="input_text" name="input_text" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['input_text'])) {
            $input = $_POST['input_text'];
            $reversed = strrev($input);
            echo "<div class='mt-4 text-center'>";
            echo "<h3>" . ($reversed) . "</h3>";
            echo "<p>-Output Reverse Words:</p>";
            echo "</div>";
        }
        ?>
    </div>

    <footer class="footer2">
        <h3 class="">&copy; Praktikum Pemrogram Web IF 2022</h3>
    </footer>
</body>
</html>