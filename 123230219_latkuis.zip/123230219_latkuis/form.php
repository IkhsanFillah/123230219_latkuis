<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kuis</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="latkuis.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bgnav">
        <div class="d-flex fs-6 font-weight-bold">    
            <div class="mt-2 ms-5 hnav">Kuis 123230219</div>
            <ul class="d-flex list-unstyled">
                <li class="ms-5 p-2 mt-1"><a href="home.php" class="text-decoration-none text-dark anav">home</a></li>
                <li class="p-2 mt-1"><a href="form.php" class="text-decoration-none text-dark anav">form</a></li>
                <li class="p-2 mt-1"><a href="perulangan.php" class="text-decoration-none text-dark anav">perulangan</a></li>
            </ul>
        </div>
    </nav>
    <div class="container">
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Tampilkan biodata
            echo "<div class='card bgform'>";
            echo "<div class='card-header'><h2>Biodata Mahasiswa</h2></div>";
            echo "<div class='card-body'>";
            echo "<p><strong>NIM:</strong> " . ($_POST['nim']) . "</p>";
            echo "<p><strong>Nama:</strong> " . htmlspecialchars($_POST['nama']) . "</p>";
            echo "<p><strong>Tempat, Tanggal Lahir:</strong> " . htmlspecialchars($_POST['tempat_lahir']) . ", " . htmlspecialchars($_POST['tanggal_lahir']) . "</p>";
            echo "<p><strong>Alamat:</strong> " . htmlspecialchars($_POST['alamat']) . "</p>";
            echo "<p><strong>Jenis Kelamin:</strong> " . ($_POST['jenis_kelamin']) . "</p>";
            echo "<p><strong>Agama:</strong> " . htmlspecialchars($_POST['agama']) . "</p>";
            echo "<p><strong>Kulianya Susah?:</strong> " . htmlspecialchars($_POST['kuliah_susah']) . "</p>";
            echo "</div>";
            echo "<div class='card-footer text-center'>";
            echo "&copy; Praktikum Pemrogram Web IF 2022";
            echo "</div>";
            echo "</div>";
        } else {
            // Tampilkan form
        ?>
        <div class="card bgform">
            <div class="card-header">
                <h2 class="mb-0">Form Biodata Mahasiswa</h2>
            </div>
            <div class="card-body">
                <form method="post" action="" class="bgform mb-4">
                    <div class="mb-3">
                        <label for="nim" class="form-label">NIM:</label>
                        <input type="text" class="form-control" id="nim" name="nim" required>
                    </div>
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama:</label>
                        <input type="text" class="form-control" id="nama" name="nama" required>
                    </div>
                    <div class="mb-3">
                        <label for="tempat_lahir" class="form-label">Tempat Lahir:</label>
                        <input type="text" class="form-control" id="tempat_lahir" name="tempat_lahir" required>
                    </div>
                    <div class="mb-3">
                        <label for="tanggal_lahir" class="form-label">Tanggal Lahir:</label>
                        <input type="date" class="form-control" id="tanggal_lahir" name="tanggal_lahir" required>
                    </div>
                    <div class="mb-3">
                        <label for="alamat" class="form-label">Alamat:</label>
                        <textarea class="form-control" id="alamat" name="alamat" rows="3" required></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Jenis Kelamin:</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" id="laki" name="jenis_kelamin" value="Laki-laki" required>
                            <label class="form-check-label" for="laki">Laki-laki</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" id="perempuan" name="jenis_kelamin" value="Perempuan" required>
                            <label class="form-check-label" for="perempuan">Perempuan</label>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="agama" class="form-label">Agama:</label>
                        <select class="form-select" id="agama" name="agama" required>
                            <option value="">Pilih salah satu</option>
                            <option value="Islam">Islam</option>
                            <option value="Kristen">Kristen</option>
                            <option value="Katolik">Katolik</option>
                            <option value="Hindu">Hindu</option>
                            <option value="Buddha">Buddha</option>
                            <option value="Konghucu">Konghucu</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Kulianya Susah?</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" id="ya" name="kuliah_susah" value="Ya" required>
                            <label class="form-check-label" for="ya">Ya</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" id="tidak" name="kuliah_susah" value="Tidak" required>
                            <label class="form-check-label" for="tidak">Tidak</label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
            <div class="card-footer text-center">
                &copy; Praktikum Pemrogram Web IF 2022
            </div>
        </div>
        <?php
        }
        ?>
    </div>
    <footer class="footer2">
        <h3 class="">&copy; Praktikum Pemrogram Web IF 2022</h3>
    </footer>
</body>
</html>